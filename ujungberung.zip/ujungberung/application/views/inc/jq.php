<!DOCTYPE HTML>
<html>
<head></head>
<body>
<!-- jQuery -->
<script src="js/jquery.min.js" type="text/javascript"></script>
<!-- jQuery UI-->
<script src="js/jquery-ui.min.js" type="text/javascript"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html><!DOCTYPE HTML>
<html>
<head></head>
<body>
<!-- jQuery -->
<script src="js/jquery.min.js" type="text/javascript"></script>
<!-- jQuery UI-->
<script src="js/jquery-ui.min.js" type="text/javascript"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>